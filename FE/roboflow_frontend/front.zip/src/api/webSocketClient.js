// src/api/webSocketClient.js
import SockJS from "sockjs-client";
import { Client } from "@stomp/stompjs";

/**
 * STOMP + SockJS WebSocket 클라이언트 생성
 *
 * 사용법 (RoboFlowDashboard에서 이미 이렇게 쓰고 있음):
 *   const ws = createWebSocketClient();
 *   ws.onConnect(handleKpi, handleEnv, handleLog);
 *   ...
 *   return () => ws.deactivate();
 */
const createWebSocketClient = () => {
  // ✅ Spring Boot WebSocketConfig.registerStompEndpoints("/ws") 와 맞춰야 함
  // SockJS 는 ws:// 가 아니라 http:// 로 호출해야 함
  const socketFactory = () => new SockJS("http://k13e103.p.ssafy.io/ws");

  const client = new Client({
    webSocketFactory: socketFactory,
    reconnectDelay: 5000,
    debug: (msg) => {
      console.log("[STOMP DEBUG]", msg);
    },
  });

  // 대시보드에서 넘겨줄 콜백들을 보관할 변수
  let kpiHandler = null;
  let envHandler = null;
  let logHandler = null;

  // 실제 STOMP 연결이 성사되었을 때 실행되는 콜백
  client.onConnect = () => {
    console.log("[STOMP] connected");

    // KPI 요약 구독
    client.subscribe("/topic/kpi-summary", (message) => {
      if (!kpiHandler) return;
      try {
        const body = JSON.parse(message.body);
        kpiHandler(body);
      } catch (e) {
        console.error("[STOMP] KPI message parse error", e);
      }
    });

    // 환경값(온도/습도) 구독
    client.subscribe("/topic/environment", (message) => {
      if (!envHandler) return;
      try {
        const body = JSON.parse(message.body);
        envHandler(body);
      } catch (e) {
        console.error("[STOMP] ENV message parse error", e);
      }
    });

    // 이벤트 로그 구독
    client.subscribe("/topic/eventlog", (message) => {
      if (!logHandler) return;
      try {
        const body = JSON.parse(message.body);
        logHandler(body);
      } catch (e) {
        console.error("[STOMP] EVENTLOG message parse error", e);
      }
    });
  };

  client.onStompError = (frame) => {
    console.error("[STOMP] broker error:", frame.headers["message"]);
  };

  client.onWebSocketError = (event) => {
    console.error("[STOMP] websocket error:", event);
  };

  // 실제로 서버와 연결 시작
  client.activate();

  // 대시보드에서 사용하는 인터페이스 형태로 래핑
  return {
    /**
     * 대시보드에서 3개의 콜백을 등록하는 메서드
     *   - onKpi(body)
     *   - onEnv(body)
     *   - onLog(body)
     */
    onConnect: (onKpi, onEnv, onLog) => {
      kpiHandler = typeof onKpi === "function" ? onKpi : null;
      envHandler = typeof onEnv === "function" ? onEnv : null;
      logHandler = typeof onLog === "function" ? onLog : null;
    },

    // 언마운트 시 호출
    deactivate: () => {
      try {
        client.deactivate();
      } catch (e) {
        console.error("[STOMP] deactivate error", e);
      }
    },
  };
};

export default createWebSocketClient;
