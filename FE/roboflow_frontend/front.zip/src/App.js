import React from "react";
import RoboFlowDashboard from "./components/RoboFlowDashboard";

export default function App() {
  return <RoboFlowDashboard />;
}